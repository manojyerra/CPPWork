#include <iostream>
#include "BigInteger.h"
#include <mach/mach_time.h>

class NumarAndDenom
{
public:
    BigInteger* numar;
    BigInteger* denom;
};


void Method2()
{
    uint64_t startTime = mach_absolute_time() / 1000000;
    
    BigInteger* bigInteger1 = new BigInteger((uint64_t)7797279247);
    
    for(int i=0; i<10; i++)
        bigInteger1->Mul(bigInteger1);

    BigInteger* bigInteger2 = new BigInteger((uint64_t)123987456789);

    for(int i=0; i<10; i++)
        bigInteger2->Mul(bigInteger2);
    
    printf("\nstarted...\n\n");
    
    BigInteger* result = BigInteger::Mul(bigInteger1, bigInteger2);
    
    uint64_t endTime = mach_absolute_time() / 1000000;
    
    string resultStr = result->GetHexString();
    
    printf("\nTime taken Norm : %d, len : %d\n", (int)(endTime - startTime), (int)resultStr.length());
    
    
//    startTime = mach_absolute_time() / 1000000;
//    
//    BigInteger* resultExpr = BigInteger::Mul_Exper(bigInteger1, bigInteger2);
//    
//    endTime = mach_absolute_time() / 1000000;
//
//    string resultExprStr = resultExpr->ToString();
//
//    printf("\nTime taken Expr : %d, len : %d\n", (int)(endTime - startTime), (int)resultExprStr.length());
//
//
//    printf("\n resulrtExpr ** :  %s\n",resultExprStr.c_str());
    
    
    printf("\n result :  %s\n",result->GetHexString().c_str());
}

void Method1()
{
    BigInteger* b1 = new BigInteger((uint64_t)779721479247);
    
    b1->Mul( new BigInteger((uint64_t)10000000000) );
    b1->Add( new BigInteger((uint64_t) 8732016463) );

    b1->Mul( new BigInteger((uint64_t)10000000) );
    b1->Add( new BigInteger((uint64_t) 4419200) );

    
    BigInteger* b2 = new BigInteger((uint64_t)15898147326221);
    
    b2->Mul( new BigInteger((uint64_t)10000000000) );
    b2->Add( new BigInteger((uint64_t) 5788341546) );
    
    b2->Mul( new BigInteger((uint64_t)10000000) );
    b2->Add( new BigInteger((uint64_t) 1888000) );
    
    printf("\n1-- :    %s\n",b1->GetHexString().c_str());
    printf("\n2-- :  %s\n",b2->GetHexString().c_str());
    
    BigInteger* sum = BigInteger::Mul(b1, b2);
    
    printf("\n3-- :  %s\n",sum->GetHexString().c_str());
}


NumarAndDenom Element(unsigned int k)
{
    NumarAndDenom numerAndDenom;
    
    numerAndDenom.numar = new BigInteger((unsigned int) 1);
    numerAndDenom.denom = new BigInteger( (uint64_t)(8 * k + 1) );
    
    return numerAndDenom;
    

//    BigInteger a( (uint64_t)(8 * k + 1) );
//    BigInteger b( (uint64_t)(8 * k + 4) );
//    BigInteger c( (uint64_t)(8 * k + 5) );
//    BigInteger d( (uint64_t)(8 * k + 6) );
//    
//    BigInteger* ab = BigInteger::Mul(&a, &b);
//    BigInteger* cd = BigInteger::Mul(&c, &d);
//    
//    BigInteger* const1 = BigInteger::Mul(&b, cd);
//    const1->MulBy2Power(2);
//    
//    BigInteger* const2 = BigInteger::Mul(&a, cd);
//    const2->MulBy2Power(1);
//    
//    BigInteger* const3 = BigInteger::Mul(ab, &d);
//    BigInteger* const4 = BigInteger::Mul(ab, &c);
//    
//    const2->Add(const3);
//    const2->Add(const4);
//    
//    NumarAndDenom numerAndDenom;
//    
//    numerAndDenom.numar = BigInteger::Subtract(const1, const2);
//    numerAndDenom.denom = BigInteger::Mul(ab, cd);
//    
//    //printf("\nN:%s",numerAndDenom.numar->ToString().c_str());
//    //printf("\nD:%s",numerAndDenom.denom->ToString().c_str());
//    
//    delete ab;
//    delete cd;
//    delete const1;
//    delete const2;
//    delete const3;
//    delete const4;
//    
//    return numerAndDenom;
}


NumarAndDenom Spigot_Level_1(int startVal, int endVal)
{
    printf("\nL1 : %d - %d",startVal, endVal);
    
    BigInteger* totalNumar = new BigInteger((unsigned int)0);
    BigInteger* totalDenom = new BigInteger((unsigned int)1);
    
    //BigInteger sixTeen = new BigInteger(16);
    
    for(int k=endVal-1 ; k>=startVal; k--)
    {
        NumarAndDenom elementND = Element( k );
        
        BigInteger* ab = BigInteger::Mul(totalNumar, elementND.denom);
        BigInteger* cd = BigInteger::Mul(totalDenom, elementND.numar);
        
        BigInteger* newNumar = BigInteger::Add(ab, cd);
        
//        printf("\nab %s",ab->ToString().c_str());
//        printf("\ncd %s",cd->ToString().c_str());
//        printf("\nNewNumar : %s", newNumar->ToString().c_str());
        
        delete ab;
        delete cd;
        delete totalNumar;
        
        totalNumar = newNumar;
        
        totalDenom->Mul( elementND.denom );
        
        if(k != startVal)
        {
            totalDenom->MulBy2Power(4);
        }
        
        delete elementND.numar;
        delete elementND.denom;
    }
    
    NumarAndDenom numerAndDenom;
    
    numerAndDenom.numar = totalNumar;
    numerAndDenom.denom = totalDenom;
    
//    printf("\nNumar : %s", totalNumar->ToString().c_str());
//    printf("\nDenom : %s", totalDenom->ToString().c_str());
    
    return numerAndDenom;
}


NumarAndDenom Spigot_Level_2(int startVal, int increment, int numTimes)
{
    BigInteger* totalNumar = new BigInteger((unsigned int)0);
    BigInteger* totalDenom = new BigInteger((unsigned int)1);
    
    int endVal = startVal + increment * numTimes;
    
    for(int k=endVal ; k>startVal; k -= increment)
    {
        //printf("\nk2 = %d", (endVal-k));
        
        NumarAndDenom nd = Spigot_Level_1(k-increment, k);
        
        BigInteger* ab = BigInteger::Mul(totalNumar, nd.denom);
        BigInteger* cd = BigInteger::Mul(totalDenom, nd.numar);
        
        BigInteger* newNumar = BigInteger::Add(ab, cd);
        
        delete ab;
        delete cd;
        delete totalNumar;
        
        totalNumar = newNumar;
        
        totalDenom->Mul( nd.denom );
        
        if(k-increment != startVal)
            totalDenom->MulBy2Power(increment * 4);
    }
    
    NumarAndDenom numerAndDenom;
    
    numerAndDenom.numar = totalNumar;
    numerAndDenom.denom = totalDenom;
    
    return numerAndDenom;
}


NumarAndDenom Spigot_Level_3(int startVal, int increment, int numTimes)
{
    BigInteger* totalNumar = new BigInteger((unsigned int)0);
    BigInteger* totalDenom = new BigInteger((unsigned int)1);
    
    int endVal = startVal + increment * numTimes;
    
    for(int k=endVal ; k>startVal; k -= increment)
    {
        printf("\nk-3 = %d", (endVal-k));
        
        NumarAndDenom nd = Spigot_Level_2(k-increment, increment/10, 10);
        
        BigInteger* ab = BigInteger::Mul(totalNumar, nd.denom);
        BigInteger* cd = BigInteger::Mul(totalDenom, nd.numar);
        
        BigInteger* newNumar = BigInteger::Add(ab, cd);
        
        delete ab;
        delete cd;
        delete totalNumar;
        
        totalNumar = newNumar;
        
        totalDenom->Mul( nd.denom );
        
        if(k-increment != startVal)
        totalDenom->MulBy2Power(increment * 4);
    }
    
    NumarAndDenom numerAndDenom;
    
    numerAndDenom.numar = totalNumar;
    numerAndDenom.denom = totalDenom;
    
    return numerAndDenom;
}


int main(int argc, const char * argv[])
{
    std::cout << "Hello, World!\n";
    
    Method2();
    
    //Method1();
    
    //Element(234567);
    
//    uint64_t startTime = mach_absolute_time() / 1000000;
//    
//    Spigot_Level_3(0, 50000/10, 10);
    
    //Spigot_Level_1(0, 20);
    
//    uint64_t endTime = mach_absolute_time() / 1000000;
//    
//    int timeTaken =(int)( endTime - startTime );
//    
//    printf("\n\nTime taken : %d\n", timeTaken);
    
    //BigInteger temp((unsigned int)0);
    
    //temp.ToString();
    
    return 0;
}
