
class Test
{
	public static void main(String args[])
	{
		new Test();
	}
	
	Test()
	{
// 		BigInteger bigInt1 = new BigInteger("23456789098768798796869080887565446554345678987654323589875432345678765434523456789098768798987654323589875432345678765434567876546787654");
// 		BigInteger bigInt2 = new BigInteger("2345678904323589875432345678765434567876546876876872345678904358987543234567876543456787654687687687234589043235898754323456787654");
// 
// 		for(int i=0; i<10; i++)
// 			bigInt1 = bigInt1.square();
// 		
// 		bigInt2 = bigInt2.square();
// 		bigInt2 = bigInt2.square();
// 		bigInt2 = bigInt2.square();
// 
// 		System.out.println("\n\n ************  *********** *********** ******** \n\n ");
// 
// 		System.out.println("Result : "+bigInt1.multiply(bigInt2));
	
		
	    long startTime = System.currentTimeMillis();
		
    	BigInteger bigDecimal1 = new BigInteger("7797279247");
    
	    for(int i=0; i<10; i++)
		    bigDecimal1 = bigDecimal1.multiply(bigDecimal1);

	    BigInteger bigDecimal2 = new BigInteger("123987456789");

	    for(int i=0; i<10; i++)
		    bigDecimal2 = bigDecimal2.multiply(bigDecimal2);
    
	    System.out.println("\nstarted...\n\n");
    
	    BigInteger result = bigDecimal1.multiply( bigDecimal2 );
    
    	long timeTaken = System.currentTimeMillis() - startTime;
    
	    System.out.println("\nTime taken Norm :"+timeTaken+" \n");
	    
	    BigInteger toHex = new BigInteger(result.toString(),(int)10);
	    
	    System.out.println("\nResult :"+toHex.toString(16)+" \n");
	    
	}
}
