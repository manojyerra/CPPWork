import java.awt.*;
import java.awt.event.*;


class RecordPause extends Frame implements ActionListener
{
	Button button;
	Robot robot = new Robot();
	boolean firstTime = true;
	
	Point recordPos = new Point(1297,94);
	
	public static void main(String[] args) throws Exception
	{
		new RecordPause();
	}
	
	RecordPause() throws Exception
	{
		setLayout(null);
		setBounds(1250, 230, 200, 100);
		
		button = new Button("Pause");
		button.setBounds(10,30,200-20,100-40);
		
		button.addActionListener(this);
		add(button);
		
		setVisible(true);
		
// 		while(true)
// 		{
// 			try
// 			{
// 				Point pos =  MouseInfo.getPointerInfo().getLocation();
// 				
// 				System.out.println(pos.x+","+pos.y);
// 
// 				Thread.sleep(1000);
// 				
// 			}catch(Exception e){e.printStackTrace();}
// 			
// 		}
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
		
		//System.out.println("button clicked...");
		
		if(button.getLabel().equals("Pause"))
		{
// 			if(firstTime)
// 			{
// 				firstTime = false;
// 
// 				robot.keyPress(KeyEvent.VK_ENTER);
// 				robot.keyRelease(KeyEvent.VK_ENTER);				
// 			}
// 			else
// 			{
// 				
// 			}

			MouseClick(recordPos.x, recordPos.y-40);			

			robot.keyPress(KeyEvent.VK_ALT);
			Thread.sleep(50);
			
			MouseClick(recordPos.x, recordPos.y);
			robot.keyRelease(KeyEvent.VK_ALT);
			
			button.setLabel("Resume");
		}
		else
		{
			button.setLabel("Pause");

			MouseClick(recordPos.x, recordPos.y-40);
			MouseClick(recordPos.x, recordPos.y);
		}
		
		}catch(Exception e){ e.printStackTrace(); }
	}
	
	void MouseClick(int x, int y) throws Exception
	{
		robot.mouseMove(x, y);
		
		robot.mousePress( InputEvent.BUTTON1_MASK );
	    Thread.sleep(200);
    	robot.mouseRelease( InputEvent.BUTTON1_MASK );
		Thread.sleep(50);    	
	}
}

